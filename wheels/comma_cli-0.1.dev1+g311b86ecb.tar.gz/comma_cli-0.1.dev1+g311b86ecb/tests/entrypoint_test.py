from __future__ import annotations

import logging
import shutil
import subprocess
from typing import TYPE_CHECKING
from venv import logger

import pytest
import tomlkit

if TYPE_CHECKING:
    from collections.abc import Generator

logger.setLevel(logging.DEBUG)


def entrypoints() -> Generator[tuple[str, str], None, None]:
    with open("pyproject.toml", "rb") as f:
        pyproject = tomlkit.load(f)
    yield from pyproject["project"]["scripts"].items()


@pytest.mark.parametrize("pair", entrypoints())
def test_help(pair: tuple[str, str]) -> None:
    k, v = pair
    result = subprocess.run([k, "--help"], check=False, capture_output=True, text=True)  # noqa: S603
    if result.returncode != 0:
        logger.error(shutil.which(k))
        logger.error(result.stderr)
        msg = f"Error running {k} --help"
        raise AssertionError(msg)
    # print(k, v)
